/**
 * CRUD Transactions - JavaScript Logic
 * 6 Column Table (No, Name, Work, SAR, Payment Type, Date)
 */

// Store current editing/deleting item
let currentItemId = null;
let selectedItems = new Set();

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', function() {
  initializeEventListeners();
  updateSelectionUI();
});

// Initialize all event listeners
function initializeEventListeners() {
  // Select All checkbox
  const selectAll = document.getElementById('selectAll');
  if (selectAll) {
    selectAll.addEventListener('change', handleSelectAll);
  }

  // Individual row checkboxes
  document.querySelectorAll('.row-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', handleRowSelect);
  });

  // Search functionality
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('input', handleSearch);
  }

  // Action buttons
  document.querySelectorAll('.view-btn').forEach(btn => {
    btn.addEventListener('click', handleView);
  });

  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', handleEdit);
  });

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', handleDelete);
  });

  document.querySelectorAll('.print-btn').forEach(btn => {
    btn.addEventListener('click', handlePrint);
  });

  // Bulk actions
  const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
  if (bulkDeleteBtn) {
    bulkDeleteBtn.addEventListener('click', handleBulkDelete);
  }

  const bulkPrintBtn = document.getElementById('bulkPrintBtn');
  if (bulkPrintBtn) {
    bulkPrintBtn.addEventListener('click', handleBulkPrint);
  }

  // Close modal on overlay click
  document.querySelectorAll('.crud-modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', function(e) {
      if (e.target === this) {
        closeModal(this.id);
      }
    });
  });

  // Keyboard shortcuts
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      closeAllModals();
    }
  });
}

// Handle Select All
function handleSelectAll(e) {
  const isChecked = e.target.checked;
  document.querySelectorAll('.row-checkbox').forEach(checkbox => {
    checkbox.checked = isChecked;
    const row = checkbox.closest('tr');
    if (isChecked) {
      selectedItems.add(row.dataset.id);
      row.classList.add('selected');
    } else {
      selectedItems.delete(row.dataset.id);
      row.classList.remove('selected');
    }
  });
  updateSelectionUI();
}

// Handle Individual Row Select
function handleRowSelect(e) {
  const row = e.target.closest('tr');
  if (e.target.checked) {
    selectedItems.add(row.dataset.id);
    row.classList.add('selected');
  } else {
    selectedItems.delete(row.dataset.id);
    row.classList.remove('selected');
  }
  
  // Update select all checkbox
  const allCheckboxes = document.querySelectorAll('.row-checkbox');
  const selectAll = document.getElementById('selectAll');
  selectAll.checked = [...allCheckboxes].every(cb => cb.checked);
  
  updateSelectionUI();
}

// Update Selection UI
function updateSelectionUI() {
  const counter = document.getElementById('selectionCounter');
  const countBadge = document.getElementById('selectedCount');
  
  if (selectedItems.size > 0) {
    counter.style.display = 'flex';
    countBadge.textContent = selectedItems.size;
  } else {
    counter.style.display = 'none';
  }
}

// Search Handler
function handleSearch(e) {
  const searchTerm = e.target.value.toLowerCase();
  const rows = document.querySelectorAll('#tableBody tr');
  
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(searchTerm) ? '' : 'none';
  });
}

// View Handler
function handleView(e) {
  const row = e.target.closest('tr');
  const cells = row.querySelectorAll('td');
  
  const data = {
    number: cells[1].textContent,
    name: cells[2].textContent,
    work: cells[3].textContent,
    sar: cells[4].textContent,
    paymentType: cells[5].textContent.trim(),
    date: cells[6].textContent
  };
  
  currentItemId = row.dataset.id;
  
  const modalBody = document.getElementById('viewModalBody');
  modalBody.innerHTML = `
    <div class="crud-view-detail">
      <span class="crud-view-label">رقم:</span>
      <span class="crud-view-value">${data.number}</span>
    </div>
    <div class="crud-view-detail">
      <span class="crud-view-label">الاسم:</span>
      <span class="crud-view-value">${data.name}</span>
    </div>
    <div class="crud-view-detail">
      <span class="crud-view-label">العمل:</span>
      <span class="crud-view-value">${data.work}</span>
    </div>
    <div class="crud-view-detail">
      <span class="crud-view-label">ريال:</span>
      <span class="crud-view-value">${data.sar}</span>
    </div>
    <div class="crud-view-detail">
      <span class="crud-view-label">نوع الدفع:</span>
      <span class="crud-view-value">${data.paymentType}</span>
    </div>
    <div class="crud-view-detail">
      <span class="crud-view-label">التاريخ:</span>
      <span class="crud-view-value">${data.date}</span>
    </div>
  `;
  
  openModal('viewModal');
}

// Edit Handler
function handleEdit(e) {
  const row = e.target.closest('tr');
  const cells = row.querySelectorAll('td');
  
  currentItemId = row.dataset.id;
  
  document.getElementById('editNumber').value = cells[1].textContent;
  document.getElementById('editName').value = cells[2].textContent;
  document.getElementById('editWork').value = cells[3].textContent;
  document.getElementById('editSar').value = cells[4].textContent.replace(/,/g, '');
  document.getElementById('editPaymentType').value = cells[5].textContent.trim();
  document.getElementById('editDate').value = cells[6].textContent;
  
  openModal('editModal');
}

// Save Edit
function saveEdit() {
  const row = document.querySelector(`tr[data-id="${currentItemId}"]`);
  if (!row) return;
  
  const cells = row.querySelectorAll('td');
  const number = document.getElementById('editNumber').value;
  const name = document.getElementById('editName').value;
  const work = document.getElementById('editWork').value;
  const sar = parseInt(document.getElementById('editSar').value).toLocaleString();
  const paymentType = document.getElementById('editPaymentType').value;
  const date = document.getElementById('editDate').value;
  
  // Get badge class
  const badgeClass = getBadgeClass(paymentType);
  
  cells[1].textContent = number;
  cells[2].textContent = name;
  cells[3].textContent = work;
  cells[4].textContent = sar;
  cells[5].innerHTML = `<span class="crud-badge ${badgeClass}">${paymentType}</span>`;
  cells[6].textContent = date;
  
  closeModal('editModal');
  showToast('تم تحديث البيانات بنجاح', 'success');
}

// Get Badge Class
function getBadgeClass(paymentType) {
  switch(paymentType) {
    case 'کاش': return 'crud-badge-cash';
    case 'شبكة': return 'crud-badge-network';
    case 'تحویل': return 'crud-badge-transfer';
    case 'نقل آخر': return 'crud-badge-other';
    default: return 'crud-badge-cash';
  }
}

// Delete Handler
function handleDelete(e) {
  const row = e.target.closest('tr');
  currentItemId = row.dataset.id;
  selectedItems.clear();
  selectedItems.add(currentItemId);
  
  document.getElementById('deleteItemInfo').textContent = 
    `سيتم حذف العنصر رقم ${row.querySelectorAll('td')[1].textContent}`;
  
  openModal('deleteModal');
}

// Bulk Delete Handler
function handleBulkDelete() {
  if (selectedItems.size === 0) {
    showToast('الرجاء تحديد عناصر للحذف', 'warning');
    return;
  }
  
  document.getElementById('deleteItemInfo').textContent = 
    `سيتم حذف ${selectedItems.size} عنصر`;
  
  openModal('deleteModal');
}

// Confirm Delete
function confirmDelete() {
  selectedItems.forEach(id => {
    const row = document.querySelector(`tr[data-id="${id}"]`);
    if (row) {
      row.style.animation = 'fadeOut 0.3s ease forwards';
      setTimeout(() => row.remove(), 300);
    }
  });
  
  selectedItems.clear();
  updateSelectionUI();
  
  // Reset select all
  document.getElementById('selectAll').checked = false;
  
  closeModal('deleteModal');
  showToast('تم الحذف بنجاح', 'success');
}

// Print Handler
function handlePrint(e) {
  const row = e.target.closest('tr');
  currentItemId = row.dataset.id;
  selectedItems.clear();
  selectedItems.add(currentItemId);
  
  preparePrintContent([row]);
  openModal('printModal');
}

// Bulk Print Handler
function handleBulkPrint() {
  if (selectedItems.size === 0) {
    showToast('الرجاء تحديد عناصر للطباعة', 'warning');
    return;
  }
  
  const rows = [...selectedItems].map(id => 
    document.querySelector(`tr[data-id="${id}"]`)
  ).filter(Boolean);
  
  preparePrintContent(rows);
  openModal('printModal');
}

// Prepare Print Content
function preparePrintContent(rows) {
  const now = new Date();
  const dateStr = now.toLocaleDateString('ar-SA', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  
  document.getElementById('printDate').textContent = `التاريخ: ${dateStr}`;
  
  let tableHTML = `
    <thead>
      <tr>
        <th>رقم</th>
        <th>الاسم</th>
        <th>العمل</th>
        <th>ريال</th>
        <th>نوع الدفع</th>
        <th>التاريخ</th>
      </tr>
    </thead>
    <tbody>
  `;
  
  rows.forEach(row => {
    const cells = row.querySelectorAll('td');
    tableHTML += `
      <tr>
        <td>${cells[1].textContent}</td>
        <td>${cells[2].textContent}</td>
        <td>${cells[3].textContent}</td>
        <td>${cells[4].textContent}</td>
        <td>${cells[5].textContent.trim()}</td>
        <td>${cells[6].textContent}</td>
      </tr>
    `;
  });
  
  tableHTML += '</tbody>';
  document.getElementById('printTableContent').innerHTML = tableHTML;
}

// Print Current Item (from View Modal)
function printCurrentItem() {
  closeModal('viewModal');
  const row = document.querySelector(`tr[data-id="${currentItemId}"]`);
  if (row) {
    preparePrintContent([row]);
    openModal('printModal');
  }
}

// Download PDF
function downloadPDF() {
  const printContent = document.querySelector('.crud-print-preview').innerHTML;
  
  const printWindow = window.open('', '', 'width=800,height=600');
  printWindow.document.write(`
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <title>طباعة - مكتب أبو عوض</title>
      <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600&family=Alexandria:wght@400;600&display=swap" rel="stylesheet">
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
          font-family: 'Rubik', sans-serif;
          padding: 30px;
          direction: rtl;
        }
        .crud-print-header {
          text-align: center;
          margin-bottom: 30px;
          padding-bottom: 20px;
          border-bottom: 2px solid #14243b;
        }
        .crud-print-logo { font-size: 48px; margin-bottom: 10px; }
        .crud-print-title {
          font-family: 'Alexandria', serif;
          font-size: 24px;
          font-weight: 600;
          color: #14243b;
        }
        .crud-print-date {
          font-size: 14px;
          color: #666;
          margin-top: 8px;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        th, td {
          border: 1px solid #ddd;
          padding: 12px;
          text-align: right;
        }
        th {
          background: #14243b;
          color: white;
          font-weight: 600;
        }
        tr:nth-child(even) { background: #f9f9f9; }
        @media print {
          body { padding: 0; }
        }
      </style>
    </head>
    <body>
      ${printContent}
      <script>
        window.onload = function() {
          window.print();
          window.onafterprint = function() { window.close(); };
        };
      </script>
    </body>
    </html>
  `);
  printWindow.document.close();
  
  closeModal('printModal');
  showToast('جاري فتح نافذة الطباعة...', 'success');
}

// Modal Functions
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  modal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  modal.classList.remove('active');
  document.body.style.overflow = '';
}

function closeAllModals() {
  document.querySelectorAll('.crud-modal-overlay').forEach(modal => {
    modal.classList.remove('active');
  });
  document.body.style.overflow = '';
}

// Toast Notification
function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `crud-toast ${type} show`;
  
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

// Add fadeOut animation
const style = document.createElement('style');
style.textContent = `
  @keyframes fadeOut {
    from { opacity: 1; transform: translateX(0); }
    to { opacity: 0; transform: translateX(20px); }
  }
`;
document.head.appendChild(style);
